using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exorcist_Controller : MonoBehaviour
{

    Animator animator;

    ExorcistMove exorcistMove;

    // Start is called before the first frame update
    void Start()
    {
        animator = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.W))
        {
            animator.SetBool("Exorcist_Walk", true);
        }
        else
        {
            animator.SetBool("Exorcist_Walk", false);
        }

        if (Input.GetMouseButtonDown(0))
        {
            animator.SetTrigger("Exorcist_Atack");
        }


        if(Input.GetKey(KeyCode.Space))
        {
            animator.SetBool("Exorcist_Die", true);
        }
        else
        {
            animator.SetBool("Exorcist_Die", false);
        }
    }
}
