using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exorcist_SE : MonoBehaviour
{

    private AudioSource audioSource;

    public AudioClip atack;
    public AudioClip damage;
    public AudioClip down;
    public AudioClip voice;
    public AudioClip DIE;

    public AudioClip atack_voice1;
    public AudioClip atack_voice2;
    public AudioClip atack_voice3;


    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void seplay_atack()
    {
        var r = Random.Range(0, 3);
        switch (r)
        {
            case 0:
                audioSource.PlayOneShot(atack_voice1);
                break;

            case 1:
                audioSource.PlayOneShot(atack_voice2);
                break;

            case 2:
                audioSource.PlayOneShot(atack_voice3);
                break;
        }
    }

    public void seplay_damage()
    {
        audioSource.PlayOneShot(damage);
    }

    public void seplay_down()
    {
        audioSource.PlayOneShot(down);
    }
    public void seplay_voice()
    {
        audioSource.PlayOneShot(voice);
    }
    public void seplay_DIE()
    {
        audioSource.PlayOneShot(DIE);
    }
}
