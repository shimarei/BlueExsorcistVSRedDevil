using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class Exorcist_AttackCon : MonoBehaviour
{
    // Start is called before the first frame update
    private GameObject AttackObj;

    PhotonView PhotonView;
    void Start()
    {
        AttackObj = GameObject.Find("Exorcist_Weapon");
        AttackObj.GetComponent<Collider>().enabled = false;


        //RPC �̂��߂� PhotonView �擾
        PhotonView = GetComponent<PhotonView>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void AttackAppearance()
    {
        //�U���̔����̃^�C�~���O

        Debug.Log("Exorcist_Attack_Start");
        AttackObj.GetComponent<Collider>().enabled = true;
    }


    public void AttackDisAppearance()
    {
        //�U���̏����̃^�C�~���O

        Debug.Log("Exorcist_Attack_Start");
        AttackObj.GetComponent<Collider>().enabled = false;
    }
}
