using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Photon.Pun;

public class ExorcistMove : MonoBehaviour
{
    // Start is called before the first frame update
    private PhotonView photonView;
    private Exorcist_Life exorcist_Life;

    private float speed = 3f;

    private GameObject cam;              //���C���J�����i�[�p
    Quaternion cameraRot, characterRot;
    private float Xsensityvity = 3f, Ysensityvity = 3f;

    private bool cursorLock = true;

    [SerializeField]private float AttackSpan;

    //�A�j���[�V�����p�֐�
    public bool IsWark_Anim;
    public bool IsAttack_Anim;

    //�ϐ��̐錾(�p�x�̐����p)
    float minX = -90f, maxX = 90f;

    void Start()
    {
        photonView = gameObject.GetComponent<PhotonView>();

        if (photonView.IsMine)
        {
            Instantiate((GameObject)Resources.Load("Blood Splatter 1"), Vector3.zero, Quaternion.identity);

            cam = GameObject.Find("Main Camera").gameObject;
            cam.transform.parent = transform;
            cam.transform.position = Vector3.zero;
            cam.transform.localPosition = new Vector3(0.04f, 1.45f, 0.11f);
            cam.GetComponent<Camera>().nearClipPlane = 0.43f;

            cam.GetComponent<Camera>().cullingMask &= ~(1 << 6);

            cameraRot = cam.transform.localRotation;
        }

        exorcist_Life = gameObject.GetComponent<Exorcist_Life>();

        characterRot = transform.localRotation;

        IsWark_Anim = false;
        IsAttack_Anim = false;

        AttackSpan = 0;



    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (photonView.IsMine)
        {
            if (exorcist_Life.checkAlive())
            {   //�����Ă���Ƃ��̏���
                //���W�ړ��̊֐�
                PosMove();

                //���_�ړ��̊֐�
                rotateCamera();

                //�U���̊֐�
                AttackFunc();
            }
            else
            {   //����ł���Ƃ��̏���

            }
        }
        
    }

    void PosMove()
    {
        var add = Vector3.zero;
        if (Input.GetKey(KeyCode.A))
        {
            add += GetAdditionalMovement(-1.0f, 0, 0);
        }
        if (Input.GetKey(KeyCode.D))
        {
            add += GetAdditionalMovement(1.0f, 0, 0);
        }
        if (Input.GetKey(KeyCode.W))
        {
            add += GetAdditionalMovement(0, 0, 1.0f);
        }
        if (Input.GetKey(KeyCode.S))
        {
            add += GetAdditionalMovement(0, 0, -1.0f);
        }


        //�����A�j���[�V�������Đ������邩
        if(add != Vector3.zero)
        {
            //�ړ��l������Ȃ�����A�j���[�V�������Đ�
            IsWark_Anim = true;
        }
        else
        {
            IsWark_Anim = false;
        }


        Vector3 NextPos = cam.transform.forward * add.z + cam.transform.right * add.x;
        NextPos = new Vector3(NextPos.x, 0, NextPos.z);

        //�ړ����̍��W��Playr�i�G�N�\�V�X�g�j�ɑ���
        transform.position += NextPos * Time.deltaTime * speed;
    }

    private Vector3 GetAdditionalMovement(float x, float y, float z)
    {
        if (!photonView.IsMine)
        {
            return Vector3.zero;
        }
        return new Vector3(x, 0, z);
    }


    private void rotateCamera()
    {
        float xRot = Input.GetAxis("Mouse X") * Ysensityvity;
        float yRot = Input.GetAxis("Mouse Y") * Xsensityvity;


        cameraRot *= Quaternion.Euler(-yRot, 0, 0);
        characterRot *= Quaternion.Euler(0, xRot, 0);

        //Update�̒��ō쐬�����֐����Ă�
        cameraRot = ClampRotation(cameraRot);

        cam.transform.localRotation = cameraRot;
        transform.localRotation = characterRot;

        UpdateCursorLock();
    }

    private void UpdateCursorLock()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            cursorLock = false;
        }
        else if (Input.GetMouseButton(0))
        {
            cursorLock = true;
        }


        if (cursorLock)
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
        else if (!cursorLock)
        {
            Cursor.lockState = CursorLockMode.None;
        }
    }

    //�p�x�����֐��̍쐬
    private Quaternion ClampRotation(Quaternion q)
    {
        //q = x,y,z,w (x,y,z�̓x�N�g���i�ʂƌ����j�Fw�̓X�J���[�i���W�Ƃ͖��֌W�̗ʁj)

        q.x /= q.w;
        q.y /= q.w;
        q.z /= q.w;
        q.w = 1f;

        float angleX = Mathf.Atan(q.x) * Mathf.Rad2Deg * 2f;

        angleX = Mathf.Clamp(angleX, minX, maxX);

        q.x = Mathf.Tan(angleX * Mathf.Deg2Rad * 0.5f);

        return q;
    }

    void AttackFunc()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if(AttackSpan <= 0f)
            {
                IsAttack_Anim = true;
                AttackSpan = 1.267f;
            }
        }
        if(AttackSpan >= 0f)
        {
            AttackSpan -= Time.deltaTime;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
    }

    public void CameraRootChange()
    {
        if (photonView.IsMine)
        {
            List<GameObject> list = GetAllChildren.GetAll(gameObject);
            foreach (GameObject obj in list)
            {
                obj.gameObject.layer = 6;
            }
            cam.transform.parent = GameObject.Find("mixamorig:Head").transform;
        }
    }

}

public static class GetAllChildren
{
    public static List<GameObject> GetAll(this GameObject obj)
    {
        List<GameObject> allChildren = new List<GameObject>();
        GetChildren(obj, ref allChildren);
        return allChildren;
    }

    //�q�v�f���擾���ă��X�g�ɒǉ�
    public static void GetChildren(GameObject obj, ref List<GameObject> allChildren)
    {
        Transform children = obj.GetComponentInChildren<Transform>();
        //�q�v�f�����Ȃ���ΏI��
        if (children.childCount == 0)
        {
            return;
        }
        foreach (Transform ob in children)
        {
            allChildren.Add(ob.gameObject);
            GetChildren(ob.gameObject, ref allChildren);
        }
    }
}