using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exorcist_Anim : MonoBehaviour
{
    Animator animator;

    private ExorcistMove _Move;

    private Exorcist_Life _Life;

    private bool IsOnce_Die;

    // Start is called before the first frame update
    void Start()
    {
        animator = gameObject.GetComponent<Animator>();
        _Move = gameObject.GetComponent<ExorcistMove>();
        _Life = gameObject.GetComponent<Exorcist_Life>();

        IsOnce_Die = true;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        if (_Move.IsWark_Anim)
        {
            animator.SetBool("Exorcist_Walk", true);
        }
        else
        {
            animator.SetBool("Exorcist_Walk", false);
        }

        if (_Move.IsAttack_Anim)
        {
            animator.SetTrigger("Exorcist_Atack");
            _Move.IsAttack_Anim = false;
        }

        if (!_Life.checkAlive())
        {
            if (IsOnce_Die)
            {
                animator.SetBool("Exorcist_Die", true);
                IsOnce_Die = false;
                GameObject.Find("MainMgr").GetComponent<MainMgr>().exorcistDie();
            }
            return;
        }
        else
        {
            animator.SetBool("Exorcist_Die", false);
        }



    }
}
