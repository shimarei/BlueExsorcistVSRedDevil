using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class Devil_Controller : MonoBehaviour
{

    Animator animator;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        //if (!GetComponent<PhotonView>().IsMine)
        //{
        //    return;
        //}
        //if (Input.GetKey(KeyCode.W))
        //{
        //    animator.SetBool("Devil_Walk", true);
        //}
        //else
        //{
        //    animator.SetBool("Devil_Walk", false);
        //}

        //if (Input.GetMouseButtonDown(0))
        //{
        //    animator.SetTrigger("Devil_Atack");
        //}

        //if (Input.GetKey(KeyCode.Space))
        //{
        //    animator.SetBool("Devil_Die", true);
        //}
        //else
        //{
        //    animator.SetBool("Devil_Die", false);
        //}

    }
}
