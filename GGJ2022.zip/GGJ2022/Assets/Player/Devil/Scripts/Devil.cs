using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class Devil : MonoBehaviourPunCallbacks, IPunObservable
{
    Devil_SE se;
    [SerializeField]  bool huntMode;
    Animator animator;
    bool seFlg;
    // Start is called before the first frame update
    void Start()
    {
        se = this.GetComponent<Devil_SE>();
        seFlg = true;
        huntMode = false;
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!GetComponent<PhotonView>().IsMine)
        {
            return;
        }
        if (Input.GetKey(KeyCode.W))
        {
            animator.SetBool("Devil_Walk", true);
        }
        else
        {
            animator.SetBool("Devil_Walk", false);
        }
        if (huntMode)
        {
            if (Input.GetMouseButtonDown(0))
            {
                animator.SetTrigger("Devil_Atack");
            }

        }
    }
    public void OnHuntMode()
    {
        if(seFlg) {
           se.seplay_hant_transition();
           seFlg = false;
        }
        huntMode = true;
    }

    public void OffHuntMode()
    {
        huntMode = false;
        seFlg = true;
    }

    public bool GetHuntMode()
    {
        return huntMode;
    }
    /// <summary>
    /// ���܂��Ȃ�
    /// </summary>
    /// <param name="stream"></param>
    /// <param name="info"></param>
    void IPunObservable.OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        if (stream.IsWriting)
        {
            stream.SendNext(huntMode);
        }
        else
        {
            huntMode = (bool)stream.ReceiveNext();
        }
    }
}
