using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Devil_SE : MonoBehaviour
{
    private AudioSource audioSource;

    public AudioClip atack;
    public AudioClip damage;
    public AudioClip DIE;
    public AudioClip down;
    public AudioClip footstep;
    public AudioClip hant_transition;
    public AudioClip hant_charge;

    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void seplay_atack()
    {
        audioSource.PlayOneShot(atack);
    }
    public void seplay_damage()
    {
        audioSource.PlayOneShot(damage);
    }

    public void seplay_DIE()
    {
        audioSource.PlayOneShot(DIE);
    }
    public void seplay_down()
    {
        audioSource.PlayOneShot(down);
    }
    public void seplay_footstep()
    {
        audioSource.PlayOneShot(footstep);
    }
    public void seplay_hant_transition()
    {
        audioSource.PlayOneShot(hant_transition);
    }
    public void seplay_hant_charge()
    {
        audioSource.PlayOneShot(hant_charge);
    }


}
