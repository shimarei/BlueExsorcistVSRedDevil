using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class DevilLife : MonoBehaviour
{
    int life = 3;   // �������œ���
    Image[] lifeImage = new Image[3]; // �������œ���
    Animator animator;
    int die;
    // Start is called before the first frame update
    private void Awake()

    {
        if (gameObject.GetComponent<PhotonView>().IsMine)
        {
            Instantiate((GameObject)Resources.Load("DevilUI"), Vector3.zero, Quaternion.identity);
        }
    }
    void Start()
    {
        if (gameObject.GetComponent<PhotonView>().IsMine)
        {
            lifeImage[0] = GameObject.Find("Life1").GetComponent<Image>();
            lifeImage[1] = GameObject.Find("Life2").GetComponent<Image>();
            lifeImage[2] = GameObject.Find("Life3").GetComponent<Image>();
            animator = GetComponent<Animator>();
            die = 0;
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!gameObject.GetComponent<PhotonView>().IsMine)
        {
            return;
        }
            
        if(MissCheck(life) && die == 0)
        {
            die = 1;
        }
        if(die == 1)
        {
            animator.SetBool("Devil_Die", true);
            die = 2;
            Invoke("DevilDie", 4.3f);
        }else {
            animator.SetBool("Devil_Die", false);
        }
        
    }


    private void DevilDie()
    {
        GameObject.Find("MainMgr").GetComponent<MainMgr>().GotoSelect();
    }



    // �Ԃ�l�̓_���[�W���󂯂���̃��C�t
    public int Damege()
    {
        if (life > 0)
        {
            life--; // 1�_���󂯂�
            lifeImage[life].gameObject.SetActive(false);
        }
        return life;
    }

    // �������|����Ă��邩�ǂ����̃`�F�b�N
    public bool MissCheck(int life)
    {
        if(life <= 0)
        {
            return true;
        }
        return false;
    }
}
