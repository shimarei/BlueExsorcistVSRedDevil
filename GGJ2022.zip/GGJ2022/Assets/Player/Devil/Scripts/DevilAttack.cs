using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
public class DevilAttack : MonoBehaviour
{
    public BoxCollider attackColider;
    public float hitStart = 0;
    public float hitExit = 0;
    [SerializeField]float animCount;
    bool attackFlg;
    // Start is called before the first frame update
    void Start()
    {
        //attackFlg = false;
        //animCount = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        //if(Input.GetMouseButtonDown(0) && !attackFlg) {
        //    //OnAttackCollider();
        //    attackFlg = true;
        //    animCount = 0f;
        //    Debug.Log("in");
        //}

        //if(attackFlg)
        //{
        //    animCount += Time.deltaTime;
        //    if(animCount >= hitStart && animCount <= hitExit)
        //    {
        //        OnAttackCollider();
        //    }else
        //    {
        //        OffAttackCollider();
        //        attackFlg = false;
        //        //animCount = 0f;
        //    }
        //}
    }

    [PunRPC]
    public void OnAttackCollider()
    {
        Debug.Log("Devil_Attack_Start");
        attackColider.enabled = true;
    }

    [PunRPC]
    public void OffAttackCollider()
    {
        Debug.Log("Devil_Attack_Stop");
        attackColider.enabled = false;
    }
}
