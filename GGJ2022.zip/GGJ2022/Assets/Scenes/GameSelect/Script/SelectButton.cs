using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class SelectButton : MonoBehaviour
{

    private static bool jobFlg;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnClickBlueButton()
    {
        jobFlg = true;
        //Debug.Log("�G�N�\�V�X�g!!!!!");
        //SceneManager.LoadScene("MainScene");
        GameMgr.Instance.GotoMain();
    }

    public void OnClickRedButton()
    {
        jobFlg = false;
        //Debug.Log("�����ƌ_�񂵂܂���");
        //SceneManager.LoadScene("MainScene");
        GameMgr.Instance.GotoMain();
    }

    public bool GetFlg
    {
        get { return jobFlg; }
        set { jobFlg = value; }
    }

}
