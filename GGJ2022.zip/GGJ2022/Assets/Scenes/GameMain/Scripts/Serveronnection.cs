using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.UI;

public class Serveronnection : MonoBehaviourPunCallbacks
{

    private Text timerText;
    private GameObject timer;

    public float totalTime;
    int seconds;
    private int e_Count = 0;
    private int d_Count = 0;
    private bool activeFlg = false;
    private bool gameStart = false;

    private SelectButton selectButton;
    private GameObject mainCanvas;
    private GameObject timerCanvas;
    private GameObject startCanvas;

    // Start is called before the first frame update
    void Start()
    {

        //�}�X�^�[�T�[�o�[�ɐڑ�����
        PhotonNetwork.ConnectUsingSettings();
        selectButton = new SelectButton();
        mainCanvas = GameObject.Find("MainCanvas");
        timerCanvas = GameObject.Find("Timer");
        timerText = GameObject.Find("TimeCount").GetComponent<Text>();
        startCanvas = GameObject.Find("StartCanvas");
        timerCanvas.SetActive(false);
        startCanvas.SetActive(false);
    }

    private void Update()
    {

        //if (PhotonNetwork.CurrentRoom.PlayerCount == PhotonNetwork.CurrentRoom.MaxPlayers)
        //{
        //    activeFlg = true;
        //    startCanvas.SetActive(true);
        //}

        //if (activeFlg && Input.GetKeyDown(KeyCode.P))
        //{
        //    gameStart = true;
        //    PhotonNetwork.CurrentRoom.IsOpen = false;
        //}

        if (PhotonNetwork.CurrentRoom.PlayerCount == PhotonNetwork.CurrentRoom.MaxPlayers)
        {
            startCanvas.SetActive(false);
            mainCanvas.SetActive(false);
            timerCanvas.SetActive(true);
            if (totalTime >= 0.0f)
            {
                totalTime -= Time.deltaTime;
                seconds = (int)totalTime;
            }
            if (totalTime > 1.0f)
            {
                timerText.text = seconds.ToString();

            }
            else if (totalTime > 0.0f && totalTime < 1.0f)
            {
                timerText.text = "GO";
            }
            else
            {
                timerCanvas.SetActive(false);
            }
        }

        Debug.Log(PhotonNetwork.NickName);
    }

    public override void OnConnectedToMaster()
    {

        if (selectButton.GetFlg)
        {
            PhotonNetwork.NickName = "�G�N�\�V�X�g";
            //PhotonNetwork.JoinRandomRoom();

        }
        else
        {
            PhotonNetwork.NickName = "����";
            //PhotonNetwork.JoinOrCreateRoom("Room", new RoomOptions(), TypedLobby.Default);
            //var roomOptions = new RoomOptions();
            //roomOptions.MaxPlayers = 3;
            //PhotonNetwork.CreateRoom(null, roomOptions);
        }

        PhotonNetwork.JoinRandomRoom();

    }

    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        //PhotonNetwork.JoinRandomRoom();
        var roomOptions = new RoomOptions();
        roomOptions.MaxPlayers = 3;
        PhotonNetwork.CreateRoom(null, roomOptions);
    }

    public override void OnJoinedRoom()
    {

        var e_position = new Vector3(Random.Range(-37, -40), 1.3f, Random.Range(-20, -32));
        var d_position = new Vector3(21, 1.3f, -3.7f);

        foreach (var player in PhotonNetwork.PlayerListOthers)
        {
            if (player.ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber
                && ((player.NickName == "�G�N�\�V�X�g")
                && (PhotonNetwork.LocalPlayer.NickName == "�G�N�\�V�X�g")))
            {
                e_Count++;
            }

            if (player.ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber
                && ((player.NickName == "����")
                && (PhotonNetwork.LocalPlayer.NickName == "����")))
            {
                d_Count++;
            }
        }
        if (selectButton.GetFlg)
        {
            if ((PhotonNetwork.LocalPlayer.NickName == "�G�N�\�V�X�g" && e_Count > 1))
            {
                PhotonNetwork.LeaveRoom();
            }
            else
            {
                PhotonNetwork.Instantiate("Exorcist", e_position, Quaternion.identity);
            }
        }
        else if(!selectButton.GetFlg)
        {
            if (PhotonNetwork.LocalPlayer.NickName == "����" && d_Count > 0)
            {
                PhotonNetwork.LeaveRoom();
            }
            else
            {
                PhotonNetwork.Instantiate("Devil_model", d_position, Quaternion.identity);
            }
        }
    }

    public override void OnLeftRoom()
    {
        GameMgr.Instance.GotoSelect();
    }
}
