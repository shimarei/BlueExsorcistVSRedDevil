using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class Timer : MonoBehaviour
{
	private Text timerText;
	private GameObject timer;

	public float totalTime;
	int seconds;

	// Use this for initialization
	void Start()
	{
		timer = GameObject.Find("TimeCount");
		timerText = timer.GetComponent<Text>();
	}

	// Update is called once per frame
	void Update()
	{


	}
}